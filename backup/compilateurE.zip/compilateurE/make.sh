bison -d -x syntaxique.y 
flex  lexical.l 

#gcc -c -g syntaxique.tab.c  lex.yy.c  -lfl -o comp 
