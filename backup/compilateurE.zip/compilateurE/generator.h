void generateError(const char *error);
void test();